cmake_minimum_required(VERSION 3.5)
project(lucsys_chassis_driver)

# Default to C99
if(NOT CMAKE_C_STANDARD)
  set(CMAKE_C_STANDARD 99)
endif()

# Default to C++14
if(NOT CMAKE_CXX_STANDARD)
  set(CMAKE_CXX_STANDARD 14)
endif()

if(CMAKE_COMPILER_IS_GNUCXX OR CMAKE_CXX_COMPILER_ID MATCHES "Clang")
  add_compile_options(-Wall -Wextra -Wpedantic)
endif()

# find dependencies
find_package(ament_cmake REQUIRED)
find_package(geometry_msgs REQUIRED)
find_package(tf2_geometry_msgs REQUIRED)
find_package(turtlesim REQUIRED)
find_package(nav2_msgs REQUIRED)
find_package(nav_msgs REQUIRED)
find_package(rclcpp REQUIRED)
find_package(rclpy REQUIRED)
find_package(sensor_msgs REQUIRED)
find_package(std_msgs REQUIRED)
find_package(tf2 REQUIRED)
find_package(tf2_ros REQUIRED)
find_package(std_srvs REQUIRED)
find_package(std_msgs REQUIRED)
find_package(lucsys_robot_msg REQUIRED)
find_package(serial REQUIRED)
find_package(rosidl_default_generators REQUIRED)
# uncomment the following section in order to fill in
# further dependencies manually.
# find_package(<dependency> REQUIRED)

rosidl_generate_interfaces(${PROJECT_NAME}
    "msg/Position.msg"
)


if(BUILD_TESTING)
  find_package(ament_lint_auto REQUIRED)
  # the following line skips the linter which checks for copyrights
  # uncomment the line when a copyright and license is not present in all source files
  #set(ament_cmake_copyright_FOUND TRUE)
  # the following line skips cpplint (only works in a git repo)
  # uncomment the line when this package is not in a git repo
  #set(ament_cmake_cpplint_FOUND TRUE)
  ament_lint_auto_find_test_dependencies()
  # Recognize our actual notice through the tool's supported plugin registry.
  # Keep the copyright test enabled and scan the same source files.

  find_package(ament_cmake_pytest REQUIRED)
  ament_add_pytest_test(launch_contracts test/test_launch_contracts.py)
  ament_add_pytest_test(inverse_sqrt test/test_inverse_sqrt.py)
  ament_add_pytest_test(notice_policy test/test_notice_policy.py
    APPEND_ENV PYTHONPATH=${CMAKE_CURRENT_SOURCE_DIR}/test/notice_plugin
  )
endif()

include_directories(
  include
)


add_executable(lucsys_chassis_node src/lucsys_chassis.cpp src/Quaternion_Solution.cpp)
ament_target_dependencies(
  lucsys_chassis_node
  tf2_ros
  tf2
  tf2_geometry_msgs
  rclcpp
  std_msgs
  nav_msgs
  std_srvs
  sensor_msgs
  serial
  lucsys_robot_msg
  turtlesim
)

add_executable(ImuProcessor src/ImuProcessor.cpp src/Quaternion_Solution.cpp)
ament_target_dependencies(
  ImuProcessor
  tf2_ros
  tf2
  tf2_geometry_msgs
  rclcpp
  std_msgs
  nav_msgs
  std_srvs
  sensor_msgs
  serial
  lucsys_robot_msg
  turtlesim
)

install(TARGETS
lucsys_chassis_node ImuProcessor
DESTINATION lib/${PROJECT_NAME}
  ARCHIVE DESTINATION ${CATKIN_PACKAGE_LIB_DESTINATION}
  LIBRARY DESTINATION ${CATKIN_PACKAGE_LIB_DESTINATION}
  RUNTIME DESTINATION ${CATKIN_PACKAGE_BIN_DESTINATION}
)

install(
  DIRECTORY launch config
  DESTINATION share/${PROJECT_NAME}
)

ament_package()

if(BUILD_TESTING)
  set_tests_properties(copyright PROPERTIES
    ENVIRONMENT "PYTHONPATH=${CMAKE_CURRENT_SOURCE_DIR}/test/notice_plugin:$ENV{PYTHONPATH}"
  )
endif()
