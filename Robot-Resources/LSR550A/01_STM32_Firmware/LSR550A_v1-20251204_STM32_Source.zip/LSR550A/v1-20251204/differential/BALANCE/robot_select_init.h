#ifndef __ROBOTSELECTINIT_H
#define __ROBOTSELECTINIT_H
#include "sys.h"
#include "system.h"

//Parameter structure of robot
//Robot parameter structure
typedef struct  
{
  float WheelSpacing;      //Wheelspacing, Mec_Car is half wheelspacing // Wheel spacing, for mecanum car it's half wheel spacing
  float AxleSpacing;       //Axlespacing, Mec_Car is half axlespacing // Wheelbase Wheat wheel carts have half axles
  int   GearRatio;         //Motor_gear_ratio // Motor reduction ratio
  int   EncoderAccuracy;   //Number_of_encoder_lines // Encoder accuracy (number of encoder lines)
  float WheelDiameter;     //Diameter of driving wheel // Diameter of the driving wheel
  float OmniTurnRadiaus;   //Rotation radius of omnidirectional chassis // Rotation radius of omnidirectional chassis
}Robot_Parament_InitTypeDef;


//Wheel_axlespacing // Axle distance
#define   SENIOR_AKM_axlespacing           0.320f 
#define   TOP_AKM_DL_axlespacing           0.549f 
#define   LONG_AKM_axlespacing             0.480f 
#define   TOP_AKM_BS_axlespacing           0.503f 

//Wheel_spacing // Wheel spacing
#define   SENIOR_AKM_wheelspacing          0.323f  
#define   TOP_AKM_DL_wheelspacing          0.593f 
#define   LONG_AKM_wheelspacing            0.413f 
#define   TOP_AKM_BS_wheelspacing          0.465f 
#define   TOP_DIFF_wheelspacing            0.329f
#define   FOUR_WHEEL_DIFF_BS_wheelspacing  0.573f
#define   FOUR_WHEEL_DIFF_DL_wheelspacing  0.573f

#define   SENIOR_AKM_Tyre_Diameter      0.125
#define   TOP_AKM_DL_Tyre_Diameter      0.254
#define   TOP_DIFF_Tyre_Diameter        0.125
#define   FOUR_WHEEL_DIFF_Tyre_Diameter 0.215
#define   TOP_AKM_BS_WHEEL_Diameter     0.180

//half wheelspacing // half wheelspace
#define SENIOR_MEC_BS_wheelspacing 0.176 
#define SENIOR_MEC_DL_wheelspacing 0.247 
#define TOP_MEC_BS_wheelspacing    0.311
#define TOP_MEC_DL_wheelspacing    0.295
#define FLAGSHIP_MEC_DL_wheelspacing  0.285
#define FLAGSHIP_MEC_BS_wheelspacing  0.292
#define TOP_MEC_DL_wheelspacing_Customized    0.446 //Custom size // Custom size
#define Senior_MEC_DL_wheelspacing_Customized 0.3   //Custom size // Custom size

//half axlespacing // Half wheelbase
#define SENIOR_MEC_BS_axlespacing 0.156
#define SENIOR_MEC_DL_axlespacing 0.214 
#define TOP_MEC_BS_axlespacing    0.308
#define TOP_MEC_DL_axlespacing    0.201
#define FLAGSHIP_MEC_DL_axlespacing 0.178
#define FLAGSHIP_MEC_BS_axlespacing 0.178
#define TOP_MEC_DL_axlespacing_Customized     0.401 //Custom size // Custom size
#define Senior_MEC_DL_axlespacing_Customized  0.24  //Custom size // Custom size

//Motor_gear_ratio
//Motor reduction ratio
#define   MD36N_5_18  5.18f
#define   MD36N_27    27
#define   MD36N_51    51
#define   MD36N_71    71
#define   MD60N_18    18
#define   MD60N_47    47

//Number_of_encoder_lines
//Encoder accuracy
#define		Photoelectric_500 500
#define	  Hall_13 					13

//Mecanum wheel tire diameter series
//Mecanum tire diameter
#define		Mecanum_60  0.060f
#define		Mecanum_75  0.075f
#define		Mecanum_100 0.100f
#define		Mecanum_127 0.127f
#define		Mecanum_152 0.152f
 
//Omni wheel tire diameter series
//Omni-wheel diameter series
#define	  FullDirecion_75  0.075
#define	  FullDirecion_127 0.127
#define	  FullDirecion_152 0.152
#define	  FullDirecion_203 0.203
#define	  FullDirecion_217 0.217

//Rotation radius of omnidirectional trolley
//Radius of rotation of the omnidirectional wheel cart
#define   Omni_Turn_Radiaus_164 0.164
#define   Omni_Turn_Radiaus_180 0.160 //Revised to 160
#define   Omni_Turn_Radiaus_290 0.280 //Revised to 280

//The encoder octave depends on the encoder initialization Settings
//The number of encoder multipliers, depending on the encoder initialization settings
#define   EncoderMultiples 4
//Encoder data reading frequency
//Encoder data read frequency
#define CONTROL_FREQUENCY 100

//#define PI 3.1415f //PI //Pi

void Robot_Select(void);
#if Mec
void Robot_Init(float wheelspacing, float axlespacing, int gearratio, int Accuracy, float tyre_diameter);
#elif Omni
void Robot_Init(float omni_turn_radiaus, int gearratio, int Accuracy, float tyre_diameter);
#elif Diff
void Robot_Init(float wheelspacing,float axlespacing,int gearratio,int Accuracy,float tyre_diameter) ;

#endif

#endif
