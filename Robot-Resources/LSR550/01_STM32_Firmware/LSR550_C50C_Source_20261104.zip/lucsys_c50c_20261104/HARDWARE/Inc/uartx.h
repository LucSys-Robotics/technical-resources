#ifndef __USRATX_H
#define __USRATX_H 
#include "sys.h"

//APP controls related variable structures
typedef struct{
	u8 TurnPage;      //APP enters the turn page marker
	u8 DirectionFlag; //APP directional signs
	u8 ParamSaveFlag; //APP saves parameter flags
	u8 ParamSendflag; //APP sends data flags
	u8 TurnFlag;      //APP turn sign
}APP_CONTROL_t;


extern APP_CONTROL_t appkey;
void APPKey_Param_Init(APP_CONTROL_t *p);

/*--------UART1 config--------*/
#define ENABLE_UART1_CLOCK  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE)
#if 1 //PA9��PA10
#define ENABLE_UART1_TX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE)
#define ENABLE_UART1_RX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE)
#define UART1_TX_PORT       GPIOA
#define UART1_RX_PORT       GPIOA
#define UART1_TX_PIN        GPIO_Pin_9
#define UART1_RX_PIN        GPIO_Pin_10
#define UART1_TX_Soure      GPIO_PinSource9
#define UART1_RX_Soure      GPIO_PinSource10
#else //PB6��PB7
#define ENABLE_UART1_TX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE)
#define ENABLE_UART1_RX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE)
#define UART1_TX_PORT       GPIOB
#define UART1_RX_PORT       GPIOB
#define UART1_PIN_TX        GPIO_Pin_6
#define UART1_PIN_RX        GPIO_Pin_7
#define UART1_TX_Soure      GPIO_PinSource6
#define UART1_RX_Soure      GPIO_PinSource7
#endif
/*----------------------------------*/

/*--------UART1 Interface Fun --------*/
void UART1_Init(u32 bound);
void uart1_send(u8 data);
/*----------------------------------*/

/*--------UART2 config--------*/
#define ENABLE_UART2_CLOCK  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE)
#if 1 //PD5��PD6
#define ENABLE_UART2_TX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE)
#define ENABLE_UART2_RX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE)
#define UART2_TX_PORT       GPIOD
#define UART2_RX_PORT       GPIOD
#define UART2_TX_PIN        GPIO_Pin_5
#define UART2_RX_PIN        GPIO_Pin_6
#define UART2_TX_Soure      GPIO_PinSource5
#define UART2_RX_Soure      GPIO_PinSource6
#else 

#endif
/*----------------------------------*/

/*--------UART2 Interface Fun --------*/
#define UART2_TX_TIMEOUT_MS  5
#define UART2_TX_WAIT_LIMIT  200000UL
void UART2_Init(u32 bound);
u8 uart2_send(u8 data); // 0: Send successful, 1: Send timeout
/*----------------------------------*/


/*--------UART3 config--------*/
#define ENABLE_UART3_CLOCK  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE)
#if 1 //PB10��PB11
#define ENABLE_UART3_TX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE)
#define ENABLE_UART3_RX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE)
#define UART3_TX_PORT       GPIOB
#define UART3_RX_PORT       GPIOB
#define UART3_TX_PIN        GPIO_Pin_10
#define UART3_RX_PIN        GPIO_Pin_11
#define UART3_TX_Soure      GPIO_PinSource10
#define UART3_RX_Soure      GPIO_PinSource11
#else //PD8��PD9
#define ENABLE_UART3_TX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE)
#define ENABLE_UART3_RX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE)
#define UART3_TX_PORT       GPIOD
#define UART3_RX_PORT       GPIOD
#define UART3_PIN_TX        GPIO_Pin_8
#define UART3_PIN_RX        GPIO_Pin_9
#define UART3_TX_Soure      GPIO_PinSource8
#define UART3_RX_Soure      GPIO_PinSource9
#endif
/*----------------------------------*/

/*--------UART3 Interface Fun --------*/
void UART3_Init(u32 bound);
void uart3_send(u8 data);
/*----------------------------------*/

/*--------UART4 config--------*/
#define ENABLE_UART4_CLOCK  RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,ENABLE)
#if 1 //PC10��PC11
#define ENABLE_UART4_TX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE)
#define ENABLE_UART4_RX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE)
#define UART4_TX_PORT       GPIOC
#define UART4_RX_PORT       GPIOC
#define UART4_TX_PIN        GPIO_Pin_10
#define UART4_RX_PIN        GPIO_Pin_11
#define UART4_TX_Soure      GPIO_PinSource10
#define UART4_RX_Soure      GPIO_PinSource11
#else //PA0��PA1
#define ENABLE_UART4_TX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE)
#define ENABLE_UART4_RX_PIN_CLOCK   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE)
#define UART4_TX_PORT       GPIOA
#define UART4_RX_PORT       GPIOA
#define UART4_PIN_TX        GPIO_Pin_0
#define UART4_PIN_RX        GPIO_Pin_1
#define UART4_TX_Soure      GPIO_PinSource0
#define UART4_RX_Soure      GPIO_PinSource1
#endif
/*----------------------------------*/

/*--------UART4 Interface Fun --------*/
void UART4_Init(u32 bound);
void uart4_send(u8 data);
void BlueTooth_UsartConfig(void);
/*----------------------------------*/


#endif

